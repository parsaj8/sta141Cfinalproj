test_that("printing blblm works", {
  fit <- blblm(Murder ~  Assault + UrbanPop, data = USArrests, m = 7, B = 1000)
  test.case <- cat("blblm model:", capture.output(fit$formula))
  expect_equal(cat("blblm model:","Murder ~ Assault + UrbanPop"), test.case)
})
