test_that("blblm coef works", {
  fit <- blblm(Murder ~  Assault + UrbanPop, data = USArrests, m = 7, B = 1000)
  check <- c(3.45827457, 0.04922251, -0.02070660)
  names(check) <- c("(Intercept)", "Assault", "UrbanPop")
  expect_equal( round(coef(fit),8), check)
})
