test_that("confint for blblm works", {
  fit <- blblm(Murder ~  Assault + UrbanPop, data = USArrests, m = 7, B = 1000)
  test <- matrix(data = round(c(0.04152002, -0.05443763, 0.05608303, 0.01886159), 8), ncol = 2, nrow = 2)
  rownames(test) <- c("Assault", "UrbanPop")
  colnames(test) <- c("2.5%", "97.5%")
  expect_equal(test, round(confint(fit, c("Assault", "UrbanPop")), 8))
})
