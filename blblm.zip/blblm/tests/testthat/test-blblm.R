test_that("blblm works", {
  fit <- blblm(Murder ~  Assault + UrbanPop, data = USArrests, m = 7, B = 1000)
  expect_equal(length(fit$estimates), 7)
  for (i in length(fit$estimates)){
    expect_equal(length(fit$estimates[[i]]), 1000)
  }
})
