test_that("predict for blblm works", {
  fit <- blblm(Murder ~  Assault + UrbanPop, data = USArrests, m = 7, B = 1000)
  test <- matrix(data = round(c(9.806321, 11.749781, 8.884119, 11.184631, 10.77149, 12.40338), 5), ncol = 3, nrow = 2)
  colnames(test) <- c("fit", "lwr", "upr")
  rownames(test) <- c("1", "2")
  expect_equal(test, round(predict(fit, data.frame(Assault = c(150, 200), UrbanPop = c(50, 75)), confidence = TRUE), 5))
})
