test_that("sigma works", {
  fit <- blblm(Murder ~  Assault + UrbanPop, data = USArrests, m = 7, B = 1000)
  test.sse <- sigma(fit)
  expect_equal(1.505991, round(test.sse, 6))
})
