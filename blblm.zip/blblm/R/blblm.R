#' @import purrr
#' @import stats
#' @import parallel
#' @import furrr
#' @importFrom magrittr %>%
#' @aliases blblm-package
#' @details
#' Linear Regression with Little Bag of Bootstraps
"_PACKAGE"


## quiets concerns of R CMD check re: the .'s that appear in pipelines
# from https://github.com/jennybc/googlesheets/blob/master/R/googlesheets.R
utils::globalVariables(c("."))


#' Use the BLB algorithm to Create a Linear Model
#'
#' Given a formula for a linear model, number of subsamples, and times to resample, create a BLB linear model with extra options to parallelize.
#'
#' @param formula formula
#'
#' @param data data.frame containg the variables to be in the model
#' @param m integer specifying the number of subsample groups
#' @param B integer specifying the number of Bootstrap samles to generate
#' @param use_parallel logical; specifies whether the user would like to parallelize the computation of the model
#' @param num_workers integer; the number of workers to be used for paralellization
#' @param seed integer; specifies the seed to run the regression with
#' @param fast logical; indicate whether you would like to use the C++ version of weighted linear regression
#'
#' @export
#' @examples
#' blblm(mpg ~ wt * hp, data = mtcars, m = 3, B = 100, use_parallel = FALSE)
blblm <- function(formula, data, m = 10, B = 5000, use_parallel = FALSE, num_workers = detectCores(), seed = 2020, fast = FALSE) {
  set.seed(seed)
  data_list <- split_data(data, m)
  if(fast){
    estimates <- future_map(
      data_list,
      ~ lm_each_subsample(formula = formula, data = ., n = nrow(data), B = B, fast = TRUE))
  } else if (use_parallel){
    suppressWarnings(plan(multiprocess, workers = num_workers))
    options(future.rng.onMisuse = "ignore", seed = seed)
    estimates <- future_map(
      data_list,
      ~ lm_each_subsample(formula = formula, data = ., n = nrow(data), B = B))
  } else{
    estimates <- map(
      data_list,
      ~ lm_each_subsample(formula = formula, data = ., n = nrow(data), B = B))
  }
  res <- list(estimates = estimates, formula = formula)
  class(res) <- "blblm"
  invisible(res)
}



#split data into m parts of approximated equal sizes
split_data <- function(data, m) {
  idx <- sample.int(m, nrow(data), replace = TRUE)
  data %>% split(idx)
}


#compute the estimates
lm_each_subsample <- function(formula, data, n, B, fast = FALSE) {
  # drop the original closure of formula,
  # otherwise the formula will pick a wrong variable from the global scope.
  environment(formula) <- environment()
  m <- model.frame(formula, data)
  X <- model.matrix(formula, m)
  y <- model.response(m)
  if(fast){
    replicate(B, fastLm(X, y, n), simplify = FALSE)
  } else{
    replicate(B, lm1(X, y, n), simplify = FALSE)
  }

}



#compute the regression estimates for a blb dataset
lm1 <- function(X, y, n) {
  freqs <- as.vector(rmultinom(1, n, rep(1, nrow(X))))
  fit <- lm.wfit(X, y, freqs)
  list(coef = blbcoef(fit), sigma = blbsigma(fit))
}


fastLm <- function(X, y, n){
  freqs <- as.vector(rmultinom(1, n, rep(1, nrow(X))))
  fit <- fastLm_w(X, y, freqs)
  list(coef = blbcoef(fit), sigma = blbsigma(fit))
}


#compute the coefficients from fit
blbcoef <- function(fit) {
  coef(fit)
}


#compute sigma from fit
blbsigma <- function(fit) {
  p <- fit$rank
  e <- fit$residuals
  w <- fit$weights
  sqrt(sum(w * (e^2)) / (sum(w) - p))
}



#' Print the model
#'
#' Present the model that has been created, including the names of both dependent and independent variables.
#'
#' @param x blblm model
#'
#' @param ... additional arguments
#'
#' @export
#' @examples fit <- blblm(mpg ~ wt * hp, data = mtcars, m = 3, B = 100, use_parallel = FALSE)
#' print(fit)
#' @method print blblm
print.blblm <- function(x, ...) {
  cat("blblm model:", capture.output(x$formula))
  cat("\n")
}


#' Computation of the SSE
#'
#' Return the sums of squared errors (SSE) for the BLB model given
#'
#' @param object blblm model
#'
#' @param confidence logical specifying whether or not to return a confidence interval for the SSE
#' @param level numeric specifying the level of confidence interval to calculate
#' @param ... additional arguments
#'
#' @export
#' @examples fit <- blblm(mpg ~ wt * hp, data = mtcars, m = 3, B = 100, use_parallel = FALSE)
#'  sigma(fit, confidence = TRUE, level = 0.99)
#' @method sigma blblm
sigma.blblm <- function(object, confidence = FALSE, level = 0.95, ...) {
  est <- object$estimates
  sigma <- mean(map_dbl(est, ~ mean(map_dbl(., "sigma"))))
  if (confidence) {
    alpha <- 1 - level
    limits <- est %>%
      map_mean(~ quantile(map_dbl(., "sigma"), c(alpha / 2, 1 - alpha / 2))) %>%
      set_names(NULL)
    return(c(sigma = sigma, lwr = limits[1], upr = limits[2]))
  } else {
    return(sigma)
  }
}

#' Find coefficients of blblm
#'
#' Return the regression coefficients for the BLB model given
#'
#' @param object a blblm object
#'
#' @param ... additional arguments
#'
#' @export
#' @examples fit <- blblm(mpg ~ wt * hp, data = mtcars, m = 3, B = 100, use_parallel = FALSE)
#' coef(fit)
#' @method coef blblm
coef.blblm <- function(object, ...) {
  est <- object$estimates
  map_mean(est, ~ map_cbind(., "coef") %>% rowMeans())
}


#' Create Confidence Interval for blblm Coefficients
#'
#' Create a 1-alpha percent confidence interval for each of the coefficients obtained from the blblm model fit
#'
#' @param object a blblm object
#'
#' @param parm character
#' @param level numeric specifying the level of confidence interval to calculate
#' @param ... additional parameters
#'
#' @export
#' @examples fit <- blblm(mpg ~ wt * hp, data = mtcars, m = 3, B = 100)
#' confint(fit, c("wt", "hp"))
#' @method confint blblm
confint.blblm <- function(object, parm = NULL, level = 0.95, ...) {
  if (is.null(parm)) {
    parm <- attr(terms(object$formula), "term.labels")
  }
  alpha <- 1 - level
  est <- object$estimates
  out <- map_rbind(parm, function(p) {
    map_mean(est, ~ map_dbl(., list("coef", p)) %>% quantile(c(alpha / 2, 1 - alpha / 2)))
  })
  if (is.vector(out)) {
    out <- as.matrix(t(out))
  }
  dimnames(out)[[1]] <- parm
  out
}

#' Predict using a blblm model
#'
#' Given a blblm model and a data frame containing specific values of the predictor variables, make a prediction for the respons variable.
#'
#' @param object a blblm object
#'
#' @param new_data data.frame containing the values of the explnatory variables in the model
#' @param confidence logical specifying whether or not to return a prediction interval
#' @param level numeric specifying the level of confidence interval to calculate
#' @param ... additional arguments
#'
#' @export
#' @examples fit <- blblm(mpg ~ wt * hp, data = mtcars, m = 3, B = 100)
#' predict(fit, data.frame(wt = c(2.5, 3), hp = c(150, 170)))
#' predict(fit, data.frame(wt = c(2.5, 3), hp = c(150, 170)), confidence = TRUE)
#' @method predict blblm
predict.blblm <- function(object, new_data, confidence = FALSE, level = 0.95, ...) {
  est <- object$estimates
  X <- model.matrix(reformulate(attr(terms(object$formula), "term.labels")), new_data)
  if (confidence) {
    map_mean(est, ~ map_cbind(., ~ X %*% .$coef) %>%
      apply(1, mean_lwr_upr, level = level) %>%
      t())
  } else {
    map_mean(est, ~ map_cbind(., ~ X %*% .$coef) %>% rowMeans())
  }
}


mean_lwr_upr <- function(x, level = 0.95) {
  alpha <- 1 - level
  c(fit = mean(x), quantile(x, c(alpha / 2, 1 - alpha / 2)) %>% set_names(c("lwr", "upr")))
}

map_mean <- function(.x, .f, ...) {
  (map(.x, .f, ...) %>% reduce(`+`)) / length(.x)
}

map_cbind <- function(.x, .f, ...) {
  map(.x, .f, ...) %>% reduce(cbind)
}

map_rbind <- function(.x, .f, ...) {
  map(.x, .f, ...) %>% reduce(rbind)
}
