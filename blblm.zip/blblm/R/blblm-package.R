## usethis namespace: start
#' @importFrom Rcpp sourceCpp
#' @useDynLib blblm, .registration = TRUE
## usethis namespace: end
NULL
