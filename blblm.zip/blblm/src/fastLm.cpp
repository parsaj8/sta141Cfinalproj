#include <RcppArmadillo.h>
using namespace Rcpp;

//' Compute weighted least squares solution
//'
//'
//' @param X a data matrix containing the information about the predictors
//' @param y a data vector containg values of the reponse varaible
//' @param w a vector of weights to be applied to the data points
//' @export
// [[Rcpp::export]]
List fastLm_w(const arma::mat& X, const arma::colvec& y, const arma::colvec& w) {
  int n = X.n_rows, k = X.n_cols;

  arma::colvec coef = arma::inv(arma::trans(X)*arma::diagmat(w)*X) * arma::trans(X) * arma::diagmat(w) * y;  // fit model y ~ X
  arma::colvec res  = y - X*coef;           // residuals

  // std.errors of coefficients
  double s2 = std::inner_product(res.begin(), res.end(), res.begin(), 0.0)/(n - k);

  arma::colvec std_err = arma::sqrt(s2 * arma::diagvec(arma::pinv(arma::trans(X)*X)));

  return List::create(Named("coefficients") = coef,
                      Named("stderr")       = std_err,
                      Named("df.residual")  = n - k);
}
